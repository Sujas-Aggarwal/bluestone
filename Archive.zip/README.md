Due to time constraints, this was all i could made in 1 hour.
Hope I get the chance to learn more. Thanks.
Regards,
Sujas - https://github.com/Sujas-Aggarwal